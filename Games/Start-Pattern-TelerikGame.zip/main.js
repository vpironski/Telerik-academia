'use strict'
const Game = new Phaser.Game(800, 800, Phaser.AUTO, 'game-canvas', { preload, create, update })

function preload() {

}

function create() {
    console.log('Hello there :)')
}

function update() {

}